package com.example.myapplication.myapplication.myapplication.myapplication.ppvapp

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
class Activity2 : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_2)
        val petImageView = findViewById<ImageView>(R.id.petImageView)
        val feedButton = findViewById<Button>(R.id.feedButton)
        val washButton = findViewById<Button>(R.id.washButton)
        val playButton = findViewById<Button>(R.id.playButton)

        val feedTextView = findViewById<TextView>(R.id.feedTextView)
        val cleanTextView = findViewById<TextView>(R.id.cleanTextView)
        val playTextView = findViewById<TextView>(R.id.playTextView)

        //Retrieve the message passed from the first screen
        val feedMessage = intent.getStringExtra("FEED_MESSAGE")
        //Set the text of the feed TextView to the feed message
        feedTextView.text = feedMessage

        //Logic for the Feed button
        feedButton.setOnClickListener {
            //Change the pet's image to match feeding action icon
            petImageView.setImageResource(R.drawable.marcus2)


            //Update the pet's values(e.g., health, hunger,cleanliness)
            //Update the feed TextView
            feedTextView.text = getString(R.string.feed_thank_you)

            //Update the play TextView
            playTextView.text = getString(R.string.play_with_me)

        }


        //Logic for the Wash button
        washButton.setOnClickListener {
            //Change the pet's image to match cleaning action icon
            petImageView.setImageResource(R.drawable.marcus4)

            //Update the pet's status values (e.g., health ,hunger,cleanliness)
            //Update the clean textview
            cleanTextView.text = getString(R.string.clean_nice_and_clean)

        }

        // Logic for the Play button
        playButton.setOnClickListener {
            // Change the pet's image to match playing action icon
            petImageView.setImageResource(R.drawable.marcus1)

            //Update the pet's status value(e.g.,health,hunger,cleanliness)
            //Update the play TextView
            playTextView.text = getString(R.string.clean_after_playing)

        }
    }
}




