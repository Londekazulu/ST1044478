package com.example.myapplication.myapplication.myapplication.myapplication.ppvapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Button to navigate to the second screen
        val startButton = findViewById<Button>(R.id.startButton)
        startButton.setOnClickListener {
            val intent = Intent(this,Activity2::class.java)
            //Pass the message "I am hungry" as an extra with the intent
            intent.putExtra("FEED_MESSAGE","I am hungry")
            startActivity(intent)
        }
    }
}
